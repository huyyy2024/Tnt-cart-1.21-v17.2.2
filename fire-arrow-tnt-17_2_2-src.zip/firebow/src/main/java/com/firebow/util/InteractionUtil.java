package com.firebow.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/**
 * InteractionUtil v5 — corrected 1-tick pattern.
 *
 * RAIL (2 phase, cùng tick N+1):
 *   tick N:   prepareRailPlacement() → lưu railPos+slot, setPendingTarget(hitVec) → KHÔNG interact
 *   tick N+1: beforeSync() → applyBeforeSync() → movement packet mang rotation đúng
 *             executePending() cùng tick N+1 → interactBlock với rotation vừa apply
 *
 * CART: direct, rotation tính từ eyePos hiện tại, reach check conservative.
 */
public final class InteractionUtil {
    private InteractionUtil() {}

    private static volatile BlockPos pendingPos  = null;
    private static volatile int      pendingSlot = -1;
    private static volatile int      savedSlot   = -1;

    // ─── Rail ────────────────────────────────────────────────────────────────

    public static void prepareRailPlacement(MinecraftClient mc, BlockPos railPos, int railSlot) {
        ClientPlayerEntity p = mc.player;
        if (p == null) return;

        BlockPos groundPos = railPos.down();
        Vec3d    hitVec    = RotationUtil.calcHitVec(groundPos, Direction.UP);

        pendingPos  = railPos;
        pendingSlot = railSlot;
        savedSlot   = p.getInventory().selectedSlot;

        // Lưu hitVec — rotation được tính trong beforeSync tick N+1 từ eyePos lúc đó
        RotationUtil.setPendingTarget(p, hitVec);
    }

    /**
     * Gọi từ onClientTick tick N+1 — SAU beforeSync đã apply rotation.
     * Movement packet tick N+1 đã mang rotation đúng → interact consistent.
     */
    public static boolean executePending(MinecraftClient mc) {
        if (pendingPos == null) return false;
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.interactionManager == null) { clearPending(); return false; }

        BlockPos pos      = pendingPos;
        int      slot     = pendingSlot;
        int      origSlot = savedSlot;

        pendingPos  = null;
        pendingSlot = -1;
        savedSlot   = -1;

        BlockPos groundPos = pos.down();
        Vec3d    hitVec    = RotationUtil.calcHitVec(groundPos, Direction.UP);

        p.getInventory().selectedSlot = slot;
        p.swingHand(Hand.MAIN_HAND);
        mc.interactionManager.interactBlock(p, Hand.MAIN_HAND,
            new BlockHitResult(hitVec, Direction.UP, groundPos, false));
        p.getInventory().selectedSlot = origSlot;

        // Restore rotation sau interact
        RotationUtil.restoreAfterInteract(p);
        return true;
    }

    // ─── Cart ────────────────────────────────────────────────────────────────

    public static boolean placeCartDirect(MinecraftClient mc, BlockPos railPos, int cartSlot) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.interactionManager == null) return false;

        Vec3d eye    = p.getEyePos();
        Vec3d vel    = p.getVelocity();
        double vy    = p.isOnGround() ? vel.y : (vel.y - 0.08) * 0.98;
        Vec3d eyeNext = eye.add(vel.x, vy, vel.z);
        Vec3d center  = Vec3d.ofCenter(railPos);

        double distCur  = eye.squaredDistanceTo(center);
        double distNext = eyeNext.squaredDistanceTo(center);
        if (Math.max(distCur, distNext) > 4.5 * 4.5) return false;

        Vec3d   hitVec   = RotationUtil.calcHitVec(railPos, Direction.UP);
        float[] rot      = RotationUtil.calcRotationFromEye(eyeNext, hitVec);
        float   savedYaw = p.getYaw();
        float   savedPit = p.getPitch();

        RotationUtil.applyRaw(p, rot);

        int origSlot = p.getInventory().selectedSlot;
        p.getInventory().selectedSlot = cartSlot;
        p.swingHand(Hand.MAIN_HAND);
        mc.interactionManager.interactBlock(p, Hand.MAIN_HAND,
            new BlockHitResult(hitVec, Direction.UP, railPos, false));
        p.getInventory().selectedSlot = origSlot;

        RotationUtil.applyRaw(p, new float[]{ savedYaw, savedPit });
        return true;
    }

    // ─── Utils ───────────────────────────────────────────────────────────────

    public static boolean hasPending() { return pendingPos != null; }

    public static void clearPending() {
        pendingPos  = null;
        pendingSlot = -1;
        savedSlot   = -1;
        RotationUtil.clearWithoutRestore();
    }

    public static boolean inReach(ClientPlayerEntity p, BlockPos pos) {
        return inReachFrom(p.getEyePos(), pos);
    }

    public static boolean inReachFrom(Vec3d eyePos, BlockPos pos) {
        return eyePos.squaredDistanceTo(Vec3d.ofCenter(pos)) <= 4.5 * 4.5;
    }
}
