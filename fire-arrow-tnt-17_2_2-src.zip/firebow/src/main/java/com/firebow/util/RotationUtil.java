package com.firebow.util;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/**
 * Silent rotation — force movement packet pattern.
 *
 * tick N   (arrow/entity tick): prepareRailPlacement → setPendingTarget(hitVec)
 * tick N+1 (sendMovementPackets HEAD hoặc END_CLIENT_TICK):
 *   applyBeforeSync() → tính rot từ eyePos N+1 → apply → gọi force packet
 *   → interactBlock ngay sau với cùng rotation → Grim consistent
 */
public final class RotationUtil {
    private RotationUtil() {}

    private static volatile Vec3d  pendingHitVec = null;
    private static volatile float  savedYaw      = 0f;
    private static volatile float  savedPitch    = 0f;

    public static void setPendingTarget(ClientPlayerEntity player, Vec3d hitVec) {
        savedYaw      = player.getYaw();
        savedPitch    = player.getPitch();
        pendingHitVec = hitVec;
    }

    public static boolean hasPendingTarget() { return pendingHitVec != null; }

    /**
     * Tính rotation từ eyePos hiện tại → apply.
     * Gọi force movement packet ngay sau (trong beforeSync caller).
     */
    public static boolean applyBeforeSync(ClientPlayerEntity player) {
        if (pendingHitVec == null) return false;
        float[] rot = calcRotationFromEye(player.getEyePos(), pendingHitVec);
        applyRaw(player, rot);
        return true;
    }

    public static void restoreAfterInteract(ClientPlayerEntity player) {
        if (player == null || pendingHitVec == null) return;
        pendingHitVec = null;
        applyRaw(player, new float[]{ savedYaw, savedPitch });
    }

    public static void clearWithoutRestore() {
        pendingHitVec = null;
    }

    // ─── KeyboardInputMixin ──────────────────────────────────────────────────

    public static float[] getPendingRot(ClientPlayerEntity player) {
        if (pendingHitVec == null) return null;
        return calcRotationFromEye(player.getEyePos(), pendingHitVec);
    }

    // ─── Math utils ──────────────────────────────────────────────────────────

    public static float[] calcRotation(ClientPlayerEntity player, Vec3d target) {
        return calcRotationFromEye(player.getEyePos(), target);
    }

    public static float[] calcRotationFromEye(Vec3d eye, Vec3d target) {
        double dx   = target.x - eye.x;
        double dy   = target.y - eye.y;
        double dz   = target.z - eye.z;
        double dist = Math.sqrt(dx * dx + dz * dz);
        float  yaw  = (float)  Math.toDegrees(Math.atan2(-dx, dz));
        float  pitch= (float) -Math.toDegrees(Math.atan2(dy, dist));
        return new float[]{ yaw, pitch };
    }

    public static Vec3d calcHitVec(BlockPos pos, Direction face) {
        return Vec3d.ofCenter(pos).add(
            face.getOffsetX() * 0.4999,
            face.getOffsetY() * 0.4999,
            face.getOffsetZ() * 0.4999
        );
    }

    public static void applyRaw(ClientPlayerEntity player, float[] rot) {
        player.setYaw(rot[0]);
        player.setPitch(rot[1]);
        player.headYaw = rot[0];
        player.bodyYaw = rot[0];
    }
}
